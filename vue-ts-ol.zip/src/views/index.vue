<script lang="ts" setup></script>

<template>
  <nav flex flex-col>
    <div class="router-test">
      <span>router test</span>
      <ul>
        <li> <router-link to="/ol-map">跳转到ol-map</router-link> </li>
        <li> <router-link to="/point-test">跳转到point-test</router-link> </li>
      </ul>
    </div>
  </nav>
</template>

<style lang="scss" scoped>
  nav {
    margin: 1rem;
  }
  span {
    // line-height: 40px;
  }
</style>
