import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    // name: 'IndexPage',
    // meta: {
    //   title: '首页',
    //   keepAlive: true,
    //   requireAuth: true
    // },
    component: () => import('@/views/index.vue')
    // redirect: '/request'
  },
  {
    path: '/ol-map',
    // name: 'JueJin element',
    component: () => import('@/views/ol/ol-overview.vue')
    // component: () => import('@/views/index.vue')
    // redirect: '/'
  },
  {
    path: '/point-test',
    // name: 'JueJin element',
    component: () => import('@/views/point-test.vue')
    // component: () => import('@/views/index.vue')
    // redirect: '/'
  }
];

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes
});
export default router;
