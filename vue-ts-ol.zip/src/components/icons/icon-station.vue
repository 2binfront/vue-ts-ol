<template>
  <svg :class="svgClass" aria-hidden="true" v-on="$listeners">
    <use :xlink:href=".//assets/svg/station.svg" />
  </svg>
</template>
