<script lang="ts" setup></script>

<template>
  <!-- <el-config-provider :locale="locale"> -->
  <RouterView />
  <!-- </el-config-provider> -->
</template>

<style lang="scss" scoped></style>
