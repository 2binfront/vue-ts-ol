# vue + ol +ts + elment-plus

个人前端项目脚手架，持续更新

vite 打包，vue+ts，ui 选用 element plus，vue 配套 pinia、vue-router，选用 axios 封装 http 请求

样式选用 scss+unocss，搭配 unocss 插件食用

选用 openlayers 做地图应用

prettier+eslint 做代码规范管理，搭配插件食用

commitizen 和 standard-version 做版本信息管理，安装在全局了所以没放这

待更新：i18n 做国际化，团队项目时强制提交信息校验和代码规范化（husky+git hooks）
