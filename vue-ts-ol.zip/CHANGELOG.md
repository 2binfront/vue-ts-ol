# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.2](https://github.com/2binfront/vue-ts-ol/compare/v0.0.1...v0.0.2) (2023-03-28)


### Features

* first map(no layers) ([a5c84f6](https://github.com/2binfront/vue-ts-ol/commit/a5c84f6aea620b5dc3d7261e40ea8c2e13703900))

### 0.0.1 (2023-03-27)


### Features

* scaffolding init 3480efb
